<?php

/*
 * Plugin Name: Related Projects
 * Plugin URI: http://wordpress.org/extend/plugins/related-links/
 * Description: Allows Admins to select related projects and attach them to a project beging created. Original plugin is Related Links by 
 * Triggvy Gunderson. I extended it to use the grid icons to make it easier to use in our site's cms.
 * Version: 1.0
 * Author: Christian Ramirez (Based on the Related Links plugin by Triggvy Gunderson)
 * Author URI: http://www.pkt.com
 * License: GPLv3
 *
 *

 *
 */
 
 
// ------------------------------------------
// backend
// ------------------------------------------


include_once('classes/class-related-links-settings.php');
include_once('classes/class-related-links-box.php');
include_once('classes/class-related-links-widget.php');

// initialize objects
$Related_Links_Settings = new Related_Links_Settings();
$Related_Links_Box = new Related_Links_Box();
$Related_Links_Widget = new Related_Links_Widget();

// add or remove default settings and classes
register_activation_hook( __FILE__, array( $Related_Links_Settings, 'add_default_settings' ) );

// ------------------------------------------
// frontend
// ------------------------------------------


/**
 * Get a list of related links.
 *
 * @param $post_id int (optional) The post id for which you want to retreive the links, if null it will pull from global $post.
 * @param $post_type string (optional) Filter by all registered post types, if null it will pull all post types.
 * @return array The array is keyed.
 */
if ( !function_exists( 'get_related_links' ) ) 
{
function get_related_links( $post_type = null, $post_id = null )
{
	global $post;
	
	if ( empty( $post_id ) ) 
	{
		$post_id = $post->ID;
	}
	
	// Get the meta information	
	$meta = get_post_meta( $post_id, '_related_links', true );
	$values = array();

	// Parse it
	if( !empty( $meta['posts'] ) )
	{
		foreach( $meta['posts'] as $id ) 
		{	
			$is_custom = strrpos( $id, 'custom_' );
			
			if( $is_custom !== false )
			{
				// Read the custom meta data
				$custom_meta = $meta['custom'][$id];
				$custom_meta[1] = ($custom_meta[1] == '') ? null : $custom_meta[1];
				
				// Push custom values
				if( $post_type == 'custom' || empty( $post_type ) )
				{		
					$values[] = array('id' => null, 'title' => $custom_meta[0], 'url' => $custom_meta[1], 'type' => null);
				}
			}
			else
			{
				// Check if the post exists
				$found_post = get_post( $id );
				$icon = get_fields($found_post->ID);
				$icon = $icon['grid_icon'];
				$icon = $icon['url'];


				
				if( !empty( $found_post ) && $found_post->post_status != 'trash' && $found_post->post_status != 'draft' )
				{
					// Push posts values
					if( $post_type == get_post_type($id) || empty( $post_type ) )
					{
						$values[] = array('id' => $id, 'title' => $found_post->post_title, 'url' => get_permalink($id), 'type' => $found_post->post_type, 'icon' => $icon );
					}
				}
			}		
		}
	}

	return $values;
}
}

/**
 * Get a unordered list of related links for the current post.
 */
if ( !function_exists( 'related_links' ) ) 
{
function related_links()
{
	$related_links = get_related_links(); ?>
	<?php if ( !empty( $related_links ) ) : ?>
	<ul class="small-block-grid-2 related-projects">
	<?php foreach ( $related_links as $link ): ?>
		<li><a href="<?php echo $link['url']; ?>"><img src="<?php echo $link['icon']; ?>" style="width:100%;" /><span class="related-project-container"><span class="related-project-title"><?php echo $link['title']; ?></span></span></a></li>
	<?php endforeach; ?>
	</ul>
	<?php endif; ?>
	<?php
}
}

?>
