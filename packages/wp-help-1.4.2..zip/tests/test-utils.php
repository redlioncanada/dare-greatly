<?php

class CWS_WP_Help_Utils extends CWS_WP_Help_TestCase {
	function test_tests() {
		$this->assertTrue( true );
	}
}
