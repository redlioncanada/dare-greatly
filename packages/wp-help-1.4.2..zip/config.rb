css_dir         = "css"
sass_dir        = "css"
images_dir      = "images"
javascripts_dir = "js"

relative_assets = true
output_style    = :compressed
