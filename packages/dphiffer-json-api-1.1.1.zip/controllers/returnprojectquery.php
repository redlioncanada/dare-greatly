<?php
/*
Controller name: Return Project Query
Controller description: returns all the projects that are associated with the taxonomy and slug that is passed
*/

class JSON_API_Returnprojectquery_Controller {

public function return_projects() {

  global $json_api;
  
  $tax = $json_api->query->tax;
  $slug = $json_api->query->slug;
  $projects = array();

  $args = array(
  	'post_type' => 'project',
	 $tax => $slug

  	);

  $wp_query = new WP_Query($args);

  if( $wp_query ->have_posts() ){

  	foreach ($wp_query->posts as $post) {
  		    $post->acf = get_fields($post->ID);
            array_push($projects, $post);
        }
 
     
  }



  wp_reset_query(); 

  return array(
    'projects' => $projects
  );

}//public function

}//end class


?>