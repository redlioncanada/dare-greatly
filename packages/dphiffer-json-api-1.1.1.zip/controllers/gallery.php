<?php

class JSON_API_Gallery_Controller {

public function get_gallery_assets() {

  global $json_api;
  $postID = $json_api->query->postid;

  $currentProject = array();
  $rows = array();

  $args = array(
  	'p' => $postID, 
  	'post_type' => 'project');

  $query = new WP_Query($args);

  if ( $query->have_posts() ) {
      
	  while ( $query->have_posts() ) {
		$query->the_post();
		 array_push($currentProject, $post);
	  }
	  wp_reset_query();

	  foreach($currentProject as $post){


	  	 while ( have_rows('gallery') ) : the_row();

	  	    $image = get_sub_field('image');

	  	    $row = array(

	  	 	'mediaType' => get_sub_field('media_type'), 
	  	 	'imageURL' => $image['url'],
	  	 	'link' => get_sub_field('video_url')

	  	 	);

	  	 	array_push($rows, $row);
	  	                               
	  	 endwhile;

	 

	  } 
        
   } 

  return array(
    'gallery' => $rows
  );
}

}


?>